/* tslint:disable */
/* eslint-disable */
export function main(): void;
export function log(s: string): void;
export function get_element_by_id(id: string): Element | undefined;
export class CleanSkillsRenderer {
  free(): void;
  constructor();
  init(canvas_id: string): void;
  update(delta_time: number): void;
  render(): void;
  handle_mouse_move(x: number, y: number): void;
  handle_mouse_leave(): void;
  resize(width: number, height: number): void;
  is_ready(): boolean;
}
export class FullWasmRenderer {
  free(): void;
  constructor(canvas_id: string);
  render(delta_time: number): void;
  handle_mouse_move(client_x: number, client_y: number): void;
  handle_mouse_leave(): void;
  handle_resize(): void;
  get_hovered_skill(): any;
}
export class PureRustRenderer {
  free(): void;
  constructor();
  init(canvas_id: string, skills_data: string): void;
  set_animation_mode(mode: string): void;
  update(delta_time: number): Array<any>;
  render_to_canvas(): void;
  get_skill_at_position(x: number, y: number): string | undefined;
  is_ready(): boolean;
  get_skills_count(): number;
}
export class SimpleSkillsRenderer {
  free(): void;
  constructor();
  init(canvas_id: string, skills_data: string): void;
  set_animation_mode(mode: string): void;
  update(delta_time: number): void;
  render(): void;
  get_skill_at_position(x: number, y: number): string | undefined;
  get_skill_info(skill_name: string): any;
  resize(width: number, height: number): void;
  is_ready(): boolean;
  get_skills_count(): number;
}
export class SkillsCalculator {
  free(): void;
  constructor(skills_data: string);
  set_animation_mode(mode: string): void;
  update(delta_time: number): Array<any>;
  get_hover_info(_mouse_x: number, _mouse_y: number, _camera_matrix: string): any;
  get_skills_count(): number;
  get_all_skills_data(): Array<any>;
  get_skill_data(index: number): any;
}
export class WasmApp {
  free(): void;
  constructor();
  init(cv_data: string): void;
  update_skills(delta_time: number): Array<any>;
  set_skills_animation_mode(mode: string): void;
  handle_mouse_hover(x: number, y: number): any;
  get_all_skills_data(): Array<any>;
  is_ready(): boolean;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_cleanskillsrenderer_free: (a: number, b: number) => void;
  readonly cleanskillsrenderer_new: () => number;
  readonly cleanskillsrenderer_init: (a: number, b: number, c: number) => [number, number];
  readonly cleanskillsrenderer_update: (a: number, b: number) => void;
  readonly cleanskillsrenderer_render: (a: number) => [number, number];
  readonly cleanskillsrenderer_handle_mouse_move: (a: number, b: number, c: number) => void;
  readonly cleanskillsrenderer_handle_mouse_leave: (a: number) => void;
  readonly cleanskillsrenderer_resize: (a: number, b: number, c: number) => void;
  readonly cleanskillsrenderer_is_ready: (a: number) => number;
  readonly __wbg_simpleskillsrenderer_free: (a: number, b: number) => void;
  readonly simpleskillsrenderer_new: () => number;
  readonly simpleskillsrenderer_init: (a: number, b: number, c: number, d: number, e: number) => [number, number];
  readonly simpleskillsrenderer_set_animation_mode: (a: number, b: number, c: number) => void;
  readonly simpleskillsrenderer_update: (a: number, b: number) => void;
  readonly simpleskillsrenderer_render: (a: number) => [number, number];
  readonly simpleskillsrenderer_get_skill_at_position: (a: number, b: number, c: number) => [number, number];
  readonly simpleskillsrenderer_get_skill_info: (a: number, b: number, c: number) => any;
  readonly simpleskillsrenderer_resize: (a: number, b: number, c: number) => void;
  readonly simpleskillsrenderer_is_ready: (a: number) => number;
  readonly simpleskillsrenderer_get_skills_count: (a: number) => number;
  readonly __wbg_fullwasmrenderer_free: (a: number, b: number) => void;
  readonly fullwasmrenderer_new: (a: number, b: number) => [number, number, number];
  readonly fullwasmrenderer_render: (a: number, b: number) => [number, number];
  readonly fullwasmrenderer_handle_mouse_move: (a: number, b: number, c: number) => void;
  readonly fullwasmrenderer_handle_mouse_leave: (a: number) => void;
  readonly fullwasmrenderer_handle_resize: (a: number) => [number, number];
  readonly fullwasmrenderer_get_hovered_skill: (a: number) => any;
  readonly main: () => void;
  readonly __wbg_skillscalculator_free: (a: number, b: number) => void;
  readonly skillscalculator_new: (a: number, b: number) => [number, number, number];
  readonly skillscalculator_set_animation_mode: (a: number, b: number, c: number) => void;
  readonly skillscalculator_update: (a: number, b: number) => any;
  readonly skillscalculator_get_hover_info: (a: number, b: number, c: number, d: number, e: number) => any;
  readonly skillscalculator_get_skills_count: (a: number) => number;
  readonly skillscalculator_get_all_skills_data: (a: number) => any;
  readonly skillscalculator_get_skill_data: (a: number, b: number) => any;
  readonly __wbg_wasmapp_free: (a: number, b: number) => void;
  readonly wasmapp_new: () => number;
  readonly wasmapp_init: (a: number, b: number, c: number) => [number, number];
  readonly wasmapp_update_skills: (a: number, b: number) => any;
  readonly wasmapp_set_skills_animation_mode: (a: number, b: number, c: number) => void;
  readonly wasmapp_handle_mouse_hover: (a: number, b: number, c: number) => any;
  readonly wasmapp_get_all_skills_data: (a: number) => any;
  readonly wasmapp_is_ready: (a: number) => number;
  readonly log: (a: number, b: number) => void;
  readonly get_element_by_id: (a: number, b: number) => any;
  readonly __wbg_purerustrenderer_free: (a: number, b: number) => void;
  readonly purerustrenderer_new: () => number;
  readonly purerustrenderer_init: (a: number, b: number, c: number, d: number, e: number) => [number, number];
  readonly purerustrenderer_set_animation_mode: (a: number, b: number, c: number) => void;
  readonly purerustrenderer_update: (a: number, b: number) => any;
  readonly purerustrenderer_render_to_canvas: (a: number) => [number, number];
  readonly purerustrenderer_get_skill_at_position: (a: number, b: number, c: number) => [number, number];
  readonly purerustrenderer_is_ready: (a: number) => number;
  readonly purerustrenderer_get_skills_count: (a: number) => number;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __externref_table_alloc: () => number;
  readonly __wbindgen_export_2: WebAssembly.Table;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __externref_table_dealloc: (a: number) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
